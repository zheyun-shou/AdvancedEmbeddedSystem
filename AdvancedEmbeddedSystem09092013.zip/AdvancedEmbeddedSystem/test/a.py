import random
while True:
    print ( random.randint(0,9) )
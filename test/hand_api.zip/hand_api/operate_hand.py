import os
from random import randint
cmd = 'sudo ./api'
os.system(cmd)
#cmd = '^C'
#os.system(cmd)